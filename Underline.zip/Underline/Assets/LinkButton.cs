﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/*
    直接附加在存在Text脚本的GameObject对象即可
    仅仅支持单行且文本上下对齐方向必须居中
*/
public class LinkButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    private Text _text;
    private Image _line;
    private System.Action _clickEvent = null; //下划线点击事件

    public System.Action ClickEvent
    {
        get
        {
            return _clickEvent;
        }

        set
        {
            _clickEvent = value;
        }
    }

    // Use this for initialization
    void Start () {
        _text = transform.GetComponent<Text>();
        _text.gameObject.AddComponent<Button>().onClick.AddListener(()=> {
            if (ClickEvent != null)
                ClickEvent();
        });

        CreateUnderLine();
    }

    void CreateUnderLine()
    {
        //初始化
        GameObject obj = new GameObject();
        obj.transform.SetParent(transform, false);
        obj.name = "underline";
        _line = obj.AddComponent<Image>();
        _line.rectTransform.anchoredPosition = Vector3.zero;
        _line.rectTransform.offsetMin = Vector2.zero;
        _line.rectTransform.offsetMax = Vector2.zero;
        _line.rectTransform.anchorMin = Vector2.zero;
        _line.rectTransform.anchorMax = Vector2.zero;
        _line.rectTransform.pivot = Vector2.zero;

        //颜色和大小
        int height = _text.fontSize / 10;
        if (height == 0)
            height = 1;
        var tex = new Texture2D((int)_text.preferredWidth, height, TextureFormat.ARGB32, false);
        Color[] colors = tex.GetPixels();
        for (int i = 0; i < colors.Length; i++)
            colors[i] = new Color(_text.color.r, _text.color.g , _text.color.b, _text.color.a);
        tex.SetPixels(colors);
        tex.Apply();
        _line.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), Vector2.zero);
        _line.SetNativeSize();
        _line.rectTransform.sizeDelta = new Vector2(_line.rectTransform.sizeDelta.x, _line.rectTransform.sizeDelta.y * 0.80f);

        //坐标
        float x = 0;
        if (_text.alignment == TextAnchor.MiddleCenter)
            x = (_text.rectTransform.sizeDelta.x - _text.preferredWidth) / 2;
        if (_text.alignment == TextAnchor.MiddleRight)
            x = _text.rectTransform.sizeDelta.x - _text.preferredWidth;
        //下划线偏移量
        float offsetY = -1;
        _line.rectTransform.anchoredPosition = new Vector3(x, offsetY, 0);
    }

    /*实现下划线同步点击效果*/
    public void OnPointerDown(PointerEventData eventData)
    {
        Color[] colors = _line.sprite.texture.GetPixels();
        for (int i = 0; i < colors.Length; i++)
            colors[i] = new Color(colors[i].r, colors[i].g, colors[i].b, colors[i].a * 0.70f);
        _line.sprite.texture.SetPixels(colors);
        _line.sprite.texture.Apply();
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        Color[] colors = _line.sprite.texture.GetPixels();
        for (int i = 0; i < colors.Length; i++)
            colors[i] = new Color(colors[i].r, colors[i].g, colors[i].b, colors[i].a / 0.70f);
        _line.sprite.texture.SetPixels(colors);
        _line.sprite.texture.Apply();
    }
}
