// TypeScript file
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Item = (function (_super) {
    __extends(Item, _super);
    function Item() {
        return _super.call(this) || this;
    }
    /** 获取自定义皮肤 */
    Item.prototype.getSkinName = function () {
        return "ItemSkin";
    };
    /** 子类可重写该函数实现自定义UI绘制 */
    Item.prototype.init = function () {
    };
    return Item;
}(SuperListViewItem));
__reflect(Item.prototype, "Item");
//# sourceMappingURL=Item.js.map