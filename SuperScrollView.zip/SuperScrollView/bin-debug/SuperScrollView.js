var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * SuperScrollView
 * 1. 支持任意位置索引的增加和删除
 * 2. 支持移动到顶部，底部以及任意索引位置
 * 3. 支持官方eui.Scroller item填不满可视视图不能滑动的问题
 * 4. 新增支持下拉刷新
 * 5. 只会显示可视区域item以及缓冲item，默认四个
*/
var SuperScrollView = (function (_super) {
    __extends(SuperScrollView, _super);
    /** w:可视区域宽， h:可视区域高， isVertical：默认垂直滚动 */
    function SuperScrollView(w, h, isVertical) {
        if (isVertical === void 0) { isVertical = true; }
        var _this = _super.call(this) || this;
        /** 所有子item */
        _this._items = [];
        /** 是否是垂直滚动 */
        _this._isVertical = true;
        /** 上下或者左右可视区域缓冲个数， 默认2个*/
        _this._cacheCount = 2;
        /** 用来做填充的 */
        _this._fill = null;
        /** 下拉刷新提示 */
        _this._pullDownLab = null;
        /** 下拉刷新回调 */
        _this._pullDownFun = null;
        _this._pullDwonObj = null;
        /** 是否下拉刷新回调 */
        _this._isPullDown = false;
        _this.width = w;
        _this.height = h;
        _this._isVertical = isVertical;
        _this.init();
        return _this;
    }
    SuperScrollView.prototype.init = function () {
        this._contentView = new eui.Group();
        if (this._isVertical)
            this._contentView.layout = new eui.VerticalLayout();
        else
            this._contentView.layout = new eui.HorizontalLayout();
        this.viewport = this._contentView;
        this.bounces = true;
        this.addEventListener(eui.UIEvent.CHANGE, this.onChangeHandler, this);
        this.addEventListener(eui.UIEvent.CHANGE_END, this.onChangeEndHandler, this);
        this._fill = new eui.Rect(this.width, this.height, 0x000000);
        this._fill.alpha = 0;
        this._contentView.addChild(this._fill);
        this.changeFillSate();
    };
    /**拖动中*/
    SuperScrollView.prototype.onChangeHandler = function (event) {
        this.onRefreshShowView();
        this.refreshPullDownState();
    };
    /**拖动结束*/
    SuperScrollView.prototype.onChangeEndHandler = function (event) {
        this.onRefreshShowView();
        this.changeFillSate();
        this.checkPullDownCall();
    };
    /** 刷新下拉状态 */
    SuperScrollView.prototype.refreshPullDownState = function () {
        if (this._pullDownFun && this._isVertical) {
            if (this._contentView.scrollV < -(this._pullDownLab.y + this._pullDownLab.height + 40)) {
                this._pullDownLab.text = "松手刷新...";
                this._pullDownLab.visible = true;
                this._isPullDown = true;
            }
            else if (this._contentView.scrollV < -(this._pullDownLab.y + this._pullDownLab.height)) {
                this._pullDownLab.text = "继续下拉刷新...";
                this._pullDownLab.visible = true;
            }
            else {
                this._pullDownLab.visible = false;
            }
        }
    };
    /** 检测是否需要下拉回调 */
    SuperScrollView.prototype.checkPullDownCall = function () {
        if (this._pullDownLab) {
            if (this._isPullDown)
                this._pullDownFun.apply(this._pullDwonObj);
            this._pullDownLab.visible = false;
            this._isPullDown = false;
        }
    };
    /** 刷新当前可见视图 */
    SuperScrollView.prototype.onRefreshShowView = function () {
        if (this.getFillvisiable())
            return;
        var offset = this._contentView.scrollV;
        if (!this._isVertical)
            offset = this._contentView.scrollH;
        var idxs = this.getShowViewIdx(offset);
        for (var i = 0; i < this._contentView.numChildren; i++) {
            var child = this._contentView.getChildAt(i);
            if (i < idxs[0] || i > idxs[1]) {
                child.visible = false;
            }
            else {
                child.visible = true;
            }
        }
    };
    /** 获取可视区域索引 */
    SuperScrollView.prototype.getShowViewIdx = function (v) {
        if (this._items.length == 0)
            return [0, 0];
        var retIdxs = [0, this._items.length - 1];
        var tIdx = 0;
        var totalLen = 0;
        while (totalLen < v && tIdx < this._items.length) {
            if (this._isVertical)
                totalLen = this._items[tIdx].y;
            else
                totalLen = this._items[tIdx].x;
            tIdx++;
        }
        retIdxs[0] = tIdx;
        if ((retIdxs[0] - this._cacheCount) < 0)
            retIdxs[0] = 0;
        else
            retIdxs[0] -= this._cacheCount;
        var maxHeight = this._items[tIdx].y + this.height;
        if (!this._isVertical)
            maxHeight = this._items[tIdx].y + this.width;
        while (totalLen < maxHeight && tIdx < this._items.length) {
            if (this._isVertical)
                totalLen = this._items[tIdx].y + this._items[tIdx].height;
            else
                totalLen = this._items[tIdx].x + this._items[tIdx].width;
            tIdx++;
        }
        retIdxs[1] = tIdx;
        if ((retIdxs[1] + this._cacheCount) > (this._items.length - 1))
            retIdxs[1] = this._items.length - 1;
        else
            retIdxs[1] += this._cacheCount;
        return retIdxs;
    };
    /** 修改fill大小和位置 */
    SuperScrollView.prototype.changeFillSate = function () {
        var layout = this._contentView.layout;
        if (!layout)
            this._contentView.layout;
        var w = this.width;
        var h = this.height;
        if (this._isVertical) {
            if (this._items.length == 0) {
                h += 1;
            }
            else {
                var len = this._items[0].height;
                for (var i = 1; i < this._items.length; i++) {
                    len += this._items[i].height;
                    if (i != (this._items.length - 1))
                        len += layout.gap;
                }
                if (len > this.height)
                    h = 0;
                else
                    h = this.height - len;
            }
        }
        else {
            if (this._items.length == 0) {
                w += 1;
            }
            else {
                var len = this._items[0].height;
                for (var i = 1; i < this._items.length; i++) {
                    len += this._items[i].width;
                    if (i != (this._items.length - 1))
                        len += layout.gap;
                }
                if (len > this.width)
                    w = 0;
                else
                    w = this.width - len;
            }
        }
        this._fill.width = w;
        this._fill.height = h;
        this._contentView.setChildIndex(this._fill, this._items.length);
    };
    SuperScrollView.prototype.getFillvisiable = function () {
        if (this._isVertical)
            return this._fill.height > 0;
        if (!this._isVertical)
            return this._fill.width > 0;
    };
    /** 设置间距 */
    SuperScrollView.prototype.setlayoutGap = function (gap) {
        var layout = this._contentView.layout;
        if (!layout)
            this._contentView.layout;
        layout.gap = gap;
        this.onRefreshShowView();
    };
    /** 设置边距, 上左下右 */
    SuperScrollView.prototype.setlayoutMargin = function (margin) {
        if (margin === void 0) { margin = [0, 0, 0, 0]; }
        var layout = this._contentView.layout;
        if (!layout)
            this._contentView.layout;
        layout.paddingTop = margin[0];
        layout.paddingLeft = margin[1];
        layout.paddingBottom = margin[2];
        layout.paddingRight = margin[3];
        this.onRefreshShowView();
    };
    /** 增加item */
    SuperScrollView.prototype.addItem = function (item) {
        this._contentView.addChild(item);
        this._items.push(item);
        this.onRefreshShowView();
        this.changeFillSate();
    };
    /** 移除item */
    SuperScrollView.prototype.removeItem = function (item) {
        this._contentView.removeChild(item);
        for (var i = 0; i < this._items.length; i++) {
            if (this._items[i] == item) {
                this._items.splice(i, 1);
                break;
            }
        }
        this.onRefreshShowView();
        this.changeFillSate();
    };
    /** 增加item到指定位置 */
    SuperScrollView.prototype.addItemAtIdx = function (item, idx) {
        if (idx < 0 || idx >= this._items.length)
            return;
        this._contentView.addChildAt(item, idx);
        var tArr = [];
        for (var i = 0; i < this._items.length; i++) {
            if (i == idx)
                tArr.push(item);
            tArr.push(this._items[i]);
        }
        this._items = tArr;
        this.onRefreshShowView();
        this.changeFillSate();
    };
    /** 移除指定位置item */
    SuperScrollView.prototype.removeItemByIdx = function (idx) {
        if (idx < 0 || idx >= this._items.length)
            return;
        this._contentView.removeChildAt(idx);
        for (var i = 0; i < this._items.length; i++) {
            if (i == idx) {
                this._items.splice(i, 1);
                break;
            }
        }
        this.onRefreshShowView();
        this.changeFillSate();
    };
    /** 移除所有item */
    SuperScrollView.prototype.removeAllItem = function () {
        for (var i = (this._contentView.numChildren - 1); i >= 0; i--) {
            var child = this._contentView.getChildAt(i);
            if (child != this._fill) {
                this._contentView.removeChild(child);
            }
        }
        this._items.splice(0);
        this.moveToTop();
        this.changeFillSate();
    };
    /** 移动到顶部或者最左边 */
    SuperScrollView.prototype.moveToTop = function () {
        this._contentView.scrollH = 0;
        this._contentView.scrollV = 0;
        this.onRefreshShowView();
    };
    /** 移动到底部或者最右边 */
    SuperScrollView.prototype.moveToBottom = function () {
        if (this._isVertical) {
            this._contentView.scrollV = this._contentView.measuredHeight - this.height;
        }
        else {
            this._contentView.scrollH = this._contentView.measuredWidth - this.width;
        }
        this.onRefreshShowView();
    };
    /** 移动到指定索引item位置 */
    SuperScrollView.prototype.moveToIdx = function (idx) {
        if (idx < 0 || idx >= this._items.length)
            return;
        if (this._isVertical) {
            var y = this._items[idx].y;
            if (y > (this._contentView.measuredHeight - this.height))
                y = this._contentView.measuredHeight - this.height;
            this._contentView.scrollV = y;
        }
        else {
            var x = this._items[idx].x;
            if (x > (this._contentView.measuredWidth - this.width))
                x = this._contentView.measuredWidth - this.width;
            this._contentView.scrollH = x;
        }
        this.onRefreshShowView();
    };
    /** 设置下拉刷新回调 */
    SuperScrollView.prototype.setPullDownCallFuntion = function (fun, obj) {
        if (!this._isVertical)
            return;
        this._pullDownFun = fun;
        this._pullDwonObj = obj;
        if (!this._pullDownLab) {
            this._pullDownLab = new eui.Label("松手刷新...");
            this._pullDownLab.textColor = 0xffffff;
            this._pullDownLab.size = 24;
            this._pullDownLab.textAlign = egret.HorizontalAlign.CENTER;
            this._pullDownLab.verticalAlign = egret.VerticalAlign.MIDDLE;
            this._pullDownLab.width = this.width;
            this._pullDownLab.height = this._pullDownLab.size;
            this._pullDownLab.x = 0;
            this._pullDownLab.y = 10;
            this._pullDownLab.visible = false;
            this.addChildAt(this._pullDownLab, 0);
        }
    };
    return SuperScrollView;
}(eui.Scroller));
__reflect(SuperScrollView.prototype, "SuperScrollView");
//# sourceMappingURL=SuperScrollView.js.map