var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
// TypeScript file
var ListView = (function (_super) {
    __extends(ListView, _super);
    function ListView(scrollView) {
        var _this = _super.call(this) || this;
        _this.scrollView = scrollView;
        _this.addEventListener(eui.UIEvent.COMPLETE, _this.init, _this);
        _this.skinName = "ListViewSkin";
        return _this;
    }
    ListView.prototype.init = function () {
        var _this = this;
        this._btn0.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            var group = new eui.Group();
            group.width = 400;
            group.height = 100;
            var rect = new eui.Rect(group.width, group.height, 0xff0000);
            group.addChild(rect);
            _this.scrollView.addItem(group);
        }, this);
        this._btn1.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            var group = new eui.Group();
            group.width = 400;
            group.height = 200;
            var rect = new eui.Rect(group.width, group.height, 0x00ff00);
            group.addChild(rect);
            _this.scrollView.addItem(group);
        }, this);
        this._btn2.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.removeItemByIdx(2);
        }, this);
        this._btn3.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.removeAllItem();
        }, this);
        this._btn4.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.moveToTop();
        }, this);
        this._btn5.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.moveToBottom();
        }, this);
        this._btn6.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.moveToIdx(3);
        }, this);
        this._btn7.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.setlayoutGap(15);
        }, this);
        this._btn8.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.setlayoutGap(6);
        }, this);
        this._btn9.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.setlayoutMargin([0, 5, 0, 0]);
        }, this);
        this._btn10.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.scrollView.setlayoutMargin([0, 0, 0, 0]);
        }, this);
    };
    return ListView;
}(eui.Component));
__reflect(ListView.prototype, "ListView");
//# sourceMappingURL=ListView.js.map