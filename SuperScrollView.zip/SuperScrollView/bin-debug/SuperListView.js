var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**自定义ListViewItem  */
var SuperListViewItem = (function (_super) {
    __extends(SuperListViewItem, _super);
    function SuperListViewItem(data) {
        var _this = _super.call(this) || this;
        _this._data = null;
        _this._data = data;
        _this.skinName = _this.getSkinName();
        _this.addEventListener(eui.UIEvent.COMPLETE, _this.init, _this);
        return _this;
    }
    Object.defineProperty(SuperListViewItem.prototype, "data", {
        get: function () {
            return this._data;
        },
        set: function (data) {
            this._data = data;
        },
        enumerable: true,
        configurable: true
    });
    /** 获取自定义皮肤 */
    SuperListViewItem.prototype.getSkinName = function () {
        return "";
    };
    /** 子类可重写该函数实现自定义UI绘制 */
    SuperListViewItem.prototype.init = function () {
    };
    return SuperListViewItem;
}(eui.Component));
__reflect(SuperListViewItem.prototype, "SuperListViewItem");
/**
 * 自定义ListView
 * */
var SuperListView = (function (_super) {
    __extends(SuperListView, _super);
    function SuperListView(w, h, isVertical) {
        if (isVertical === void 0) { isVertical = true; }
        var _this = _super.call(this, w, h, isVertical) || this;
        /** 数据源 */
        _this._data = null;
        /** 列表item类的类型，非实例化对象 */
        _this._itemType = null;
        /** 当前加载数据索引 */
        _this._loadIdx = -1;
        /** 上拉加载更多 */
        _this._pullUpLab = null;
        /** 上拉刷新回调 */
        _this._pullUpFun = null;
        _this._pullUpObj = null;
        /** 是否上拉刷新回调 */
        _this._isPullUp = false;
        return _this;
    }
    Object.defineProperty(SuperListView.prototype, "data", {
        set: function (data) {
            this._data = data;
            this.initListView();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SuperListView.prototype, "itemType", {
        /** item:注意它是类的类型而不是类的实例化对象，必须继承 SuperListViewItem */
        set: function (item) {
            this._itemType = item;
            this.initListView();
        },
        enumerable: true,
        configurable: true
    });
    /** 初始化并构建所有的items */
    SuperListView.prototype.initListView = function () {
        if (this._data == null || this._itemType == null)
            return;
        var num = this._data.length - this._items.length;
        for (var i = 0; i < this._items.length; i++) {
            var item = this._items[i];
            if (item)
                item.data = this._data[i];
        }
        if (num > 0) {
            for (var i = this._items.length; i < this._data.length && this.getFillvisiable(); i++) {
                var item = (new this._itemType());
                if (item) {
                    item.data = this._data[i];
                    this.addItem(item);
                    this._loadIdx = this._items.length - 1;
                }
            }
            var len = this._data.length - this._items.length;
            if (len > 2)
                len = 2;
            for (var i = 0; i < len; i++) {
                var item = (new this._itemType());
                if (item) {
                    this._loadIdx++;
                    item.data = this._data[this._loadIdx];
                    this.addItem(item);
                    this._loadIdx = this._items.length - 1;
                }
            }
        }
        else {
            for (var i = 0; i < Math.abs(num); i++) {
                this.removeItemByIdx(this._items.length - 1);
            }
        }
        this.setPullUpCallFuntion(this.loadMore, this);
    };
    /**拖动中*/
    SuperListView.prototype.onChangeHandler = function (event) {
        _super.prototype.onChangeHandler.call(this, event);
        this.refreshPullUpState();
    };
    /**拖动结束*/
    SuperListView.prototype.onChangeEndHandler = function (event) {
        _super.prototype.onChangeEndHandler.call(this, event);
        this.checkPullUpCall();
    };
    /** 设置下拉刷新回调 */
    SuperListView.prototype.setPullUpCallFuntion = function (fun, obj) {
        if (!this._isVertical)
            return;
        this._pullUpFun = fun;
        this._pullUpObj = obj;
        if (!this._pullUpLab) {
            this._pullUpLab = new eui.Label("松手加载更多...");
            this._pullUpLab.textColor = 0xffffff;
            this._pullUpLab.size = 24;
            this._pullUpLab.textAlign = egret.HorizontalAlign.CENTER;
            this._pullUpLab.verticalAlign = egret.VerticalAlign.MIDDLE;
            this._pullUpLab.width = this.width;
            this._pullUpLab.height = this._pullUpLab.size;
            this._pullUpLab.x = 0;
            this._pullUpLab.y = this.height - this._pullUpLab.size - 10;
            this._pullUpLab.visible = false;
            this.addChildAt(this._pullUpLab, 0);
        }
    };
    /** 刷新上拉状态 */
    SuperListView.prototype.refreshPullUpState = function () {
        if (this._pullUpFun && this._isVertical) {
            var sv = this._contentView.measuredHeight - this.height;
            if (sv < 0)
                return;
            if (this._loadIdx >= (this._data.length - 1)) {
                this._pullUpLab.text = "我是有底线的...";
                this._pullUpLab.visible = true;
            }
            else if ((this._contentView.scrollV - sv) > (this.height - this._pullUpLab.y + 40)) {
                this._pullUpLab.text = "松手加载更多...";
                this._pullUpLab.visible = true;
                this._isPullUp = true;
            }
            else if ((this._contentView.scrollV - sv) > (this.height - this._pullUpLab.y)) {
                this._pullUpLab.text = "继续上拉加载更多...";
                this._pullUpLab.visible = true;
            }
            else {
                this._pullUpLab.visible = false;
            }
        }
    };
    /** 检测是否需要上拉回调 */
    SuperListView.prototype.checkPullUpCall = function () {
        if (this._pullUpLab) {
            if (this._isPullUp)
                this._pullUpFun.apply(this._pullUpObj);
            this._pullUpLab.visible = false;
            this._isPullUp = false;
        }
    };
    /**加载更多 */
    SuperListView.prototype.loadMore = function () {
        egret.log("加载更多：" + this._loadIdx);
        if (this._loadIdx >= (this._data.length - 1))
            return;
        var num = 8;
        if (this._items.length > 0) {
            num = Math.floor(this.height / this._items[0].height) + 1;
        }
        for (var i = 0; i < num; i++) {
            if (this._loadIdx >= (this._data.length - 1))
                break;
            var item = (new this._itemType());
            if (item) {
                this._loadIdx++;
                item.data = this._data[this._loadIdx];
                this.addItem(item);
            }
        }
    };
    return SuperListView;
}(SuperScrollView));
__reflect(SuperListView.prototype, "SuperListView");
//# sourceMappingURL=SuperListView.js.map