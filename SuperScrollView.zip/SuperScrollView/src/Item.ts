// TypeScript file

class Item extends SuperListViewItem {

    public constructor() {
        super();
    }

    /** 获取自定义皮肤 */
	protected getSkinName():string {
		return "ItemSkin";
	}

	/** 子类可重写该函数实现自定义UI绘制 */
	protected init():void {
		
	}

}