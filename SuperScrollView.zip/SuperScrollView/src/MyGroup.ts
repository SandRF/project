class MyGroup extends eui.Group {
	
	public constructor() {	
		super();
	}

	public set scrollV(n:number) {
		this.scrollV = n;
	}
}