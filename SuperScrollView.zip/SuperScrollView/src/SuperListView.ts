
/**自定义ListViewItem  */
class SuperListViewItem extends eui.Component {
	private _data : any = null;

	public constructor(data?:any) {
		super();
		this._data = data;

		this.skinName = this.getSkinName();
		this.addEventListener(eui.UIEvent.COMPLETE, this.init, this);
	}

	public set data(data:any) {
		this._data = data;
	}

	public get data():any {
		return this._data;
	}

	/** 获取自定义皮肤 */
	protected getSkinName():string {
		return "";
	}

	/** 子类可重写该函数实现自定义UI绘制 */
	protected init():void {

	}
}

/** 
 * 自定义ListView
 * */
class SuperListView extends SuperScrollView {
	
	/** 数据源 */
	private _data : Array<any> = null;
	/** 列表item类的类型，非实例化对象 */
	private _itemType : any = null;
	/** 当前加载数据索引 */
	private _loadIdx : number = -1;

	/** 上拉加载更多 */
	protected _pullUpLab : eui.Label = null;
	/** 上拉刷新回调 */
	protected _pullUpFun : Function = null;
	protected _pullUpObj : any = null;
	/** 是否上拉刷新回调 */
	protected _isPullUp : boolean = false;
	
	public constructor(w:number, h:number, isVertical:boolean=true) {
		super(w, h, isVertical);
	}

	public set data(data:Array<any>) {
		this._data = data;
		this.initListView();
	}
	
	/** item:注意它是类的类型而不是类的实例化对象，必须继承 SuperListViewItem */
	public set itemType(item:any) {
		this._itemType = item;
		this.initListView();
	}

	/** 初始化并构建所有的items */
	private initListView():void {
		if (this._data == null || this._itemType == null) return;

		let num = this._data.length - this._items.length;

		for (let i=0; i<this._items.length; i++) {
			let item = <SuperListViewItem>this._items[i];
			if (item) item.data = this._data[i];
		}

		if (num > 0) {
			for (let i=this._items.length; i<this._data.length && this.getFillvisiable(); i++) {
				let item = <SuperListViewItem>(new this._itemType());
				if (item) {
					item.data = this._data[i];
					this.addItem(item);
					this._loadIdx = this._items.length - 1; 
				}
			}

			let len = this._data.length - this._items.length;
			if (len > 2) len = 2;
			for (let i=0; i<len; i++) {
				let item = <SuperListViewItem>(new this._itemType());
				if (item) {
					this._loadIdx++;
					item.data = this._data[this._loadIdx];
					this.addItem(item);
					this._loadIdx = this._items.length - 1; 
				}
			}
		}
		else {
			for (let i=0; i<Math.abs(num); i++) {
				this.removeItemByIdx(this._items.length - 1);
			}
		}

		this.setPullUpCallFuntion(this.loadMore, this);
	}

	/**拖动中*/
    protected onChangeHandler(event:any) {
		super.onChangeHandler(event);
		this.refreshPullUpState();
    }
    
    /**拖动结束*/
    protected onChangeEndHandler(event:any): void {
		super.onChangeEndHandler(event);
		this.checkPullUpCall();
    }

	/** 设置下拉刷新回调 */
	protected setPullUpCallFuntion(fun:Function, obj:any):void {
		if (!this._isVertical) return;

		this._pullUpFun = fun;
		this._pullUpObj = obj;

		if (!this._pullUpLab) {
			this._pullUpLab = new eui.Label("松手加载更多...");
			this._pullUpLab.textColor = 0xffffff;
			this._pullUpLab.size = 24;
			this._pullUpLab.textAlign = egret.HorizontalAlign.CENTER;
			this._pullUpLab.verticalAlign = egret.VerticalAlign.MIDDLE;
			this._pullUpLab.width = this.width;
			this._pullUpLab.height = this._pullUpLab.size;
			this._pullUpLab.x = 0;
			this._pullUpLab.y = this.height - this._pullUpLab.size - 10;
			this._pullUpLab.visible = false;
			this.addChildAt(this._pullUpLab, 0);
		}
	}

	/** 刷新上拉状态 */
	protected refreshPullUpState():void {
		if (this._pullUpFun && this._isVertical) {
			let sv = this._contentView.measuredHeight - this.height;
			if (sv < 0) return;

			if (this._loadIdx >= (this._data.length - 1)) {
				this._pullUpLab.text = "我是有底线的...";
				this._pullUpLab.visible = true;
			}
			else if ((this._contentView.scrollV - sv) > (this.height - this._pullUpLab.y + 40)) {
				this._pullUpLab.text = "松手加载更多...";
				this._pullUpLab.visible = true;
				this._isPullUp = true;
			}
			else if ((this._contentView.scrollV - sv) > (this.height - this._pullUpLab.y)) {
				this._pullUpLab.text = "继续上拉加载更多...";
				this._pullUpLab.visible = true;
			}
			else {
				this._pullUpLab.visible = false;
			}
		}
	} 

	/** 检测是否需要上拉回调 */
	protected checkPullUpCall():void {
		if(this._pullUpLab) {
			if (this._isPullUp) this._pullUpFun.apply(this._pullUpObj);
			this._pullUpLab.visible = false;
			this._isPullUp = false;
		}
	}

	/**加载更多 */
	protected loadMore():void {

		egret.log("加载更多：" + this._loadIdx);

		if (this._loadIdx >= (this._data.length - 1)) return;

		let num = 8;
		if (this._items.length > 0) {
			num = Math.floor(this.height / this._items[0].height) + 1;
		}

		for (let i=0; i<num; i++) {
			if (this._loadIdx >= (this._data.length - 1)) break;

			let item = <SuperListViewItem>(new this._itemType());
			if (item) {
				this._loadIdx++;
				item.data = this._data[this._loadIdx];
				this.addItem(item);
			}
		}
	} 

}