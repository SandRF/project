
/**
 * SuperScrollView
 * 1. 支持任意位置索引的增加和删除
 * 2. 支持移动到顶部，底部以及任意索引位置
 * 3. 支持官方eui.Scroller item填不满可视视图不能滑动的问题
 * 4. 新增支持下拉刷新
 * 5. 只会显示可视区域item以及缓冲item，默认四个
*/
class SuperScrollView extends eui.Scroller {
	
	/** 内容视图 */
	protected _contentView : eui.Group;
	/** 所有子item */
	protected _items : Array<egret.DisplayObject> = [];
	/** 是否是垂直滚动 */
	protected _isVertical : boolean = true;

	/** 上下或者左右可视区域缓冲个数， 默认2个*/
	protected readonly _cacheCount = 2;

	/** 用来做填充的 */
	private _fill : eui.Rect = null;

	/** 下拉刷新提示 */
	private _pullDownLab : eui.Label = null;
	/** 下拉刷新回调 */
	private _pullDownFun : Function = null;
	private _pullDwonObj : any = null;
	/** 是否下拉刷新回调 */
	private _isPullDown : boolean = false;

	/** w:可视区域宽， h:可视区域高， isVertical：默认垂直滚动 */
	public constructor(w:number, h:number, isVertical:boolean=true) {
		super();

		this.width = w;
		this.height = h;
		this._isVertical = isVertical;

		this.init();
	}

	private init():void {

		this._contentView = new eui.Group();
		if (this._isVertical)
			this._contentView.layout = new eui.VerticalLayout();
		else
			this._contentView.layout = new eui.HorizontalLayout();
		this.viewport = this._contentView;

		this.bounces = true;
        this.addEventListener(eui.UIEvent.CHANGE,this.onChangeHandler,this);
        this.addEventListener(eui.UIEvent.CHANGE_END,this.onChangeEndHandler,this);	

		this._fill = new eui.Rect(this.width, this.height, 0x000000);
		this._fill.alpha = 0;
		this._contentView.addChild(this._fill);
		this.changeFillSate();

	}

	/**拖动中*/
    protected onChangeHandler(event:any) {
		this.onRefreshShowView();

		this.refreshPullDownState();
    }
    
    /**拖动结束*/
    protected onChangeEndHandler(event:any): void {
		this.onRefreshShowView();
		this.changeFillSate();

		this.checkPullDownCall();
    }

	/** 刷新下拉状态 */
	protected refreshPullDownState():void {
		if (this._pullDownFun && this._isVertical) {
			
			if (this._contentView.scrollV < -(this._pullDownLab.y + this._pullDownLab.height + 40)) {
				this._pullDownLab.text = "松手刷新...";
				this._pullDownLab.visible = true;
				this._isPullDown = true;
			}
			else if (this._contentView.scrollV < -(this._pullDownLab.y + this._pullDownLab.height)) {
				this._pullDownLab.text = "继续下拉刷新...";
				this._pullDownLab.visible = true;
			}
			else {
				this._pullDownLab.visible = false;
			}
		}
	}

	/** 检测是否需要下拉回调 */
	protected checkPullDownCall():void {
		if(this._pullDownLab) {
			if (this._isPullDown) this._pullDownFun.apply(this._pullDwonObj);
			this._pullDownLab.visible = false;
			this._isPullDown = false;
		}
	}

	/** 刷新当前可见视图 */
	protected onRefreshShowView():void {

		if (this.getFillvisiable()) return;

		let offset = this._contentView.scrollV;
		if (!this._isVertical) offset = this._contentView.scrollH;
		let idxs = this.getShowViewIdx(offset);        
		for (let i=0; i<this._contentView.numChildren; i++) {
			let child = this._contentView.getChildAt(i);
			if (i <idxs[0] || i > idxs[1]) {
				child.visible = false;
			}
			else {
				child.visible = true;
			}
		}
	}

	/** 获取可视区域索引 */
	private getShowViewIdx(v:number):Array<number> {
		if (this._items.length == 0) return [0, 0];

		let retIdxs = [0, this._items.length - 1];

		let tIdx = 0;
		let totalLen = 0;
		while(totalLen < v && tIdx < this._items.length) {
			if (this._isVertical)
				totalLen = this._items[tIdx].y;
			else
				totalLen = this._items[tIdx].x;
			tIdx++;
		}
		retIdxs[0] = tIdx;
		if ((retIdxs[0] - this._cacheCount) < 0) retIdxs[0] = 0;
		else retIdxs[0] -= this._cacheCount;

		let maxHeight = this._items[tIdx].y + this.height;
		if (!this._isVertical) maxHeight = this._items[tIdx].y + this.width;
		while (totalLen < maxHeight && tIdx < this._items.length) {
			if (this._isVertical)
				totalLen = this._items[tIdx].y + this._items[tIdx].height;
			else
				totalLen = this._items[tIdx].x + this._items[tIdx].width;
			tIdx++;
		}
		retIdxs[1] = tIdx;
		if ((retIdxs[1] + this._cacheCount) > (this._items.length - 1)) retIdxs[1] = this._items.length - 1;
		else retIdxs[1] += this._cacheCount;

		return retIdxs;
	}

	/** 修改fill大小和位置 */
	private changeFillSate():void {
		let layout = <eui.VerticalLayout>this._contentView.layout;
		if (!layout) <eui.HorizontalLayout>this._contentView.layout;

		let w = this.width;
		let h = this.height;
		if (this._isVertical) {
			if (this._items.length == 0) {
				h +=1;
			}
			else {
				let len = this._items[0].height;
				for (let i=1; i<this._items.length; i++) {
					len += this._items[i].height;
					if (i != (this._items.length - 1))
					 	len += layout.gap;
				}
				if (len > this.height)
					h = 0;
				else
					h = this.height - len; 
			}
		}
		else {
			if (this._items.length == 0) {
				w += 1;
			}
			else {
				let len = this._items[0].height;
				for (let i=1; i<this._items.length; i++) {
					len += this._items[i].width;
					if (i != (this._items.length - 1))
					 	len += layout.gap;
				}
				if (len > this.width)
					w = 0;
				else
					w = this.width - len; 
			}
		}

		this._fill.width = w;
		this._fill.height = h;

		this._contentView.setChildIndex(this._fill, this._items.length);
	}

	protected getFillvisiable():boolean {
		if (this._isVertical) return  this._fill.height > 0;
		if (!this._isVertical) return this._fill.width > 0;
	}

	/** 设置间距 */
	public setlayoutGap(gap:number):void {
		let layout = <eui.VerticalLayout>this._contentView.layout;
		if (!layout) <eui.HorizontalLayout>this._contentView.layout;
		layout.gap = gap;

		this.onRefreshShowView();
	}

	/** 设置边距, 上左下右 */
	public setlayoutMargin(margin:Array<number>=[0, 0, 0, 0]):void {
		let layout = <eui.VerticalLayout>this._contentView.layout;
		if (!layout) <eui.HorizontalLayout>this._contentView.layout;

		layout.paddingTop = margin[0];
		layout.paddingLeft = margin[1];
		layout.paddingBottom = margin[2];
		layout.paddingRight = margin[3];

		this.onRefreshShowView();
	}


	/** 增加item */
	public addItem(item:egret.DisplayObject):void {
		this._contentView.addChild(item);
		this._items.push(item);

		this.onRefreshShowView();
		this.changeFillSate();
	}

	/** 移除item */
	public removeItem(item:egret.DisplayObject):void {
		this._contentView.removeChild(item);
		for (let i=0; i<this._items.length; i++) {
			if (this._items[i] == item) {
				this._items.splice(i, 1);
				break;
			}
		}

		this.onRefreshShowView();
		this.changeFillSate();
	}

	/** 增加item到指定位置 */
	public addItemAtIdx(item:egret.DisplayObject, idx:number):void {
		if (idx < 0 || idx >= this._items.length) return;

		this._contentView.addChildAt(item, idx);

		let tArr = [];
		for (let i=0; i<this._items.length; i++) {
			if (i == idx) tArr.push(item);
			tArr.push(this._items[i]);
		}
		this._items = tArr;

		this.onRefreshShowView();
		this.changeFillSate();
	}

	/** 移除指定位置item */
	public removeItemByIdx(idx):void {
		if (idx < 0 || idx >= this._items.length) return;
		this._contentView.removeChildAt(idx);
			for (let i=0; i<this._items.length; i++) {
			if (i == idx) {
				this._items.splice(i, 1);
				break;
			}
		}

		this.onRefreshShowView();
		this.changeFillSate();
	}

	/** 移除所有item */
	public removeAllItem():void {
		for (let i=(this._contentView.numChildren - 1); i>=0; i--) {
			let child = this._contentView.getChildAt(i);
			if (child != this._fill) {
				this._contentView.removeChild(child);
			}
		}

		this._items.splice(0);
		this.moveToTop();

		this.changeFillSate();
	} 

	/** 移动到顶部或者最左边 */
	public moveToTop():void {
		this._contentView.scrollH = 0;
		this._contentView.scrollV = 0;

		this.onRefreshShowView();
	}

	/** 移动到底部或者最右边 */
	public moveToBottom():void {
		if (this._isVertical) {
			this._contentView.scrollV = this._contentView.measuredHeight - this.height;
		}
		else {
			this._contentView.scrollH = this._contentView.measuredWidth - this.width;
		}

		this.onRefreshShowView();
	}

	/** 移动到指定索引item位置 */
	public moveToIdx(idx:number):void {
		if (idx < 0 || idx >= this._items.length) return;

		if (this._isVertical) {
			let y = this._items[idx].y;
			if (y > (this._contentView.measuredHeight - this.height)) y = this._contentView.measuredHeight - this.height;
			this._contentView.scrollV = y;
		}
		else {
			let x = this._items[idx].x;
			if (x > (this._contentView.measuredWidth - this.width)) x = this._contentView.measuredWidth - this.width;
			this._contentView.scrollH = x;
		}

		this.onRefreshShowView();
	}

	/** 设置下拉刷新回调 */
	public setPullDownCallFuntion(fun:Function, obj:any):void {
		if (!this._isVertical) return;

		this._pullDownFun = fun;
		this._pullDwonObj = obj;

		if (!this._pullDownLab) {
			this._pullDownLab = new eui.Label("松手刷新...");
			this._pullDownLab.textColor = 0xffffff;
			this._pullDownLab.size = 24;
			this._pullDownLab.textAlign = egret.HorizontalAlign.CENTER;
			this._pullDownLab.verticalAlign = egret.VerticalAlign.MIDDLE;
			this._pullDownLab.width = this.width;
			this._pullDownLab.height = this._pullDownLab.size;
			this._pullDownLab.x = 0;
			this._pullDownLab.y = 10;
			this._pullDownLab.visible = false;
			this.addChildAt(this._pullDownLab, 0);
		}
	}
}