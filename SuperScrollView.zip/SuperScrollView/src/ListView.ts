
// TypeScript file
class ListView extends eui.Component {

    private _btn0 : eui.Button;
    private _btn1 : eui.Button;
    private _btn2 : eui.Button;
    private _btn3 : eui.Button;
    private _btn4 : eui.Button;
    private _btn5 : eui.Button;
    private _btn6 : eui.Button;
    private _btn7 : eui.Button;
    private _btn8 : eui.Button;
    private _btn9 : eui.Button;
    private _btn10 : eui.Button;

    private scrollView : SuperScrollView;

    public constructor(scrollView:SuperScrollView) {
        super();
        this.scrollView = scrollView;
        this.addEventListener(eui.UIEvent.COMPLETE, this.init, this);

        this.skinName = "ListViewSkin";
    }

    private init():void {

        this._btn0.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            let group = new eui.Group();
            group.width = 400;
            group.height = 100;

            let rect = new eui.Rect(group.width, group.height, 0xff0000);
            group.addChild(rect);
            this.scrollView.addItem(group);
        }, this);

        this._btn1.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            let group = new eui.Group();
            group.width = 400;
            group.height = 200;

            let rect = new eui.Rect(group.width, group.height, 0x00ff00);
            group.addChild(rect);
            this.scrollView.addItem(group);
        }, this);

        this._btn2.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.removeItemByIdx(2);
        }, this);

        this._btn3.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.removeAllItem();
        }, this);

        this._btn4.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.moveToTop();
        }, this);

        this._btn5.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.moveToBottom();
        }, this);

        this._btn6.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.moveToIdx(3);
        }, this);

         this._btn7.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.setlayoutGap(15);
        }, this);

         this._btn8.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.setlayoutGap(6);
        }, this);

         this._btn9.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
            this.scrollView.setlayoutMargin([0, 5, 0, 0]);
        }, this);

         this._btn10.addEventListener(egret.TouchEvent.TOUCH_TAP, ()=>{
           this.scrollView.setlayoutMargin([0, 0, 0, 0]);
        }, this);
       
    }

} 